const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const files = process.argv.slice(2);
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 2080, height: 1400 }, deviceScaleFactor: 1.6 });
  const page = await ctx.newPage();
  for (const f of files) {
    await page.goto('file://' + path.resolve(f));
    await page.evaluate(() => document.fonts.ready);
    await page.waitForTimeout(300);
    const el = await page.$('#fig');
    const out = f.replace(/\.html$/, '.png');
    await el.screenshot({ path: out });
    console.log('rendered', out);
  }
  await browser.close();
})();
